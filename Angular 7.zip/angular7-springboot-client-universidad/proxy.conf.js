const PROXY_CONFIG = [
    {
        context: [
            "/titulacion",
            "/persona",
            "/alumno",
            "/profesor",
            "/asignatura",
        ],
        target: "http://localhost:8080",
        secure: false
    }
]
 
module.exports = PROXY_CONFIG;