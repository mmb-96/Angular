import { Component, OnInit } from '@angular/core';
import { AlumnoService } from "../../alumno.service";
import { alumno } from '../../alumno';

@Component({
  selector: 'app-crear-alumno',
  templateUrl: './crear-alumno.component.html',
  styleUrls: ['./crear-alumno.component.css']
})
export class CrearAlumnoComponent implements OnInit {

  alumno: alumno = new alumno();
  submitted = false;

  constructor(private alumnoServicio: AlumnoService) { }

  ngOnInit() {
  }

  newAlumno(): void {
    this.submitted = false;
    this.alumno = new alumno();
  }

  save() {
    this.alumnoServicio.createAlumno(this.alumno)
      .subscribe(data => console.log(data), error => console.log(error));
    this.alumno = new alumno();
  }

  onSubmit() {
    this.submitted = true;
    this.save();
  }

}