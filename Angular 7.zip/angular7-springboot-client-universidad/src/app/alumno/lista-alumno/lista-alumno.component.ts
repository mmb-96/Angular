import { Component, OnInit } from '@angular/core';
import { Observable } from "rxjs";
import { AlumnoService } from "../../alumno.service";
import { alumno } from '../../alumno';

@Component({
  selector: 'app-lista-alumno',
  templateUrl: './lista-alumno.component.html',
  styleUrls: ['./lista-alumno.component.css']
})
export class ListaAlumnoComponent implements OnInit {
  alumnos: Observable<alumno[]>;

  constructor(private alumnoService: AlumnoService) {}

  ngOnInit() {
    this.reloadData();
  }

  reloadData() {
    this.alumnos = this.alumnoService.getAlumnoList();
  }

  deleteAlumno(dni: string) {
    this.alumnoService.deleteAlumno(dni)
      .subscribe(
        data => {
          console.log(data);
          this.reloadData();
        },
        error => console.log(error));
  }
}