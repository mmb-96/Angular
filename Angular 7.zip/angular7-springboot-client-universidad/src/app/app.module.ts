import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HttpClientModule } from '@angular/common/http';
import { CrearTitulacionComponent } from './titulacion/crear-titulacion/crear-titulacion.component';
import { DetallesTitulacionComponent } from './titulacion/detalles-titulacion/detalles-titulacion.component';
import { ListaTitulacionComponent } from './titulacion/lista-titulacion/lista-titulacion.component';
import { CrearPersonaComponent } from './persona/crear-persona/crear-persona.component';
import { ListaPersonaComponent } from './persona/lista-persona/lista-persona.component';
import { CrearAlumnoComponent } from './alumno/crear-alumno/crear-alumno.component';
import { ListaAlumnoComponent } from './alumno/lista-alumno/lista-alumno.component';
import { CrearProfesorComponent } from './profesor/crear-profesor/crear-profesor.component';
import { ListaProfesorComponent } from './profesor/lista-profesor/lista-profesor.component';
import { CrearAsignaturaComponent } from './asignatura/crear-asignatura/crear-asignatura.component';
import { ListaAsignaturaComponent } from './asignatura/lista-asignatura/lista-asignatura.component';

@NgModule({
  declarations: [
    AppComponent,
    CrearTitulacionComponent,
    DetallesTitulacionComponent,
    ListaTitulacionComponent,
    CrearPersonaComponent,
    ListaPersonaComponent,
    CrearAlumnoComponent,
    ListaAlumnoComponent,
    CrearProfesorComponent,
    ListaProfesorComponent,
    CrearAsignaturaComponent,
    ListaAsignaturaComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }