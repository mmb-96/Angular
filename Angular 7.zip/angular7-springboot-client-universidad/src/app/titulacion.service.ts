import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class TitulacionService {

  private baseUrl = '/titulacion';

  constructor(private http: HttpClient) { }

  getTitulacion(idtitulacion: string): Observable<Object> {
    return this.http.get(`${this.baseUrl}/${idtitulacion}`);
  }

  createTitulacion(titulacion: Object): Observable<Object> {
    return this.http.post(`${this.baseUrl}`, titulacion);
  }
  
  updateTitulacion(idtitulacion: string, value: any): Observable<Object> {
     return this.http.put(`${this.baseUrl}/${idtitulacion}`, value);
  }
  
  deleteTitulacion(idtitulacion: string): Observable<any> {
    return this.http.delete(`${this.baseUrl}/${idtitulacion}`, { responseType: 'text' });
  }
  
  getTitulacionList(): Observable<any> {
    return this.http.get(`${this.baseUrl}`);
  }
}