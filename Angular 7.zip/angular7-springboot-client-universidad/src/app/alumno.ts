export class alumno {
    idalumno: string;
    dni: string;
}