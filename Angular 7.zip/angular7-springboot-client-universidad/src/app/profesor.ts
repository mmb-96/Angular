export class profesor {
    idprofesor: string;
    dni: string;
}