import { Component, OnInit } from '@angular/core';
import { AsignaturaService } from "../../asignatura.service";
import { asignatura } from '../../asignatura';

@Component({
  selector: 'app-crear-asignatura',
  templateUrl: './crear-asignatura.component.html',
  styleUrls: ['./crear-asignatura.component.css']
})
export class CrearAsignaturaComponent implements OnInit {

  asignatura: asignatura = new asignatura();
  submitted = false;

  constructor(private asignaturaServicio: AsignaturaService) { }

  ngOnInit() {
  }

  newPersona(): void {
    this.submitted = false;
    this.asignatura = new asignatura();
  }

  save() {
    this.asignaturaServicio.createAsignatura(this.asignatura)
      .subscribe(data => console.log(data), error => console.log(error));
    this.asignatura = new asignatura();
  }

  onSubmit() {
    this.submitted = true;
    this.save();
  }
}