import { Component, OnInit } from '@angular/core';
import { Observable } from "rxjs";
import { AsignaturaService } from "../../asignatura.service";
import { asignatura } from '../../asignatura';

@Component({
  selector: 'app-lista-asignatura',
  templateUrl: './lista-asignatura.component.html',
  styleUrls: ['./lista-asignatura.component.css']
})
export class ListaAsignaturaComponent implements OnInit {

  asignaturas: Observable<asignatura[]>;

  constructor(private asignaturaService: AsignaturaService) {}

  ngOnInit() {
    this.reloadData();
  }

  reloadData() {
    this.asignaturas = this.asignaturaService.getAsignaturaList();
  }

  deletePersona(idasignatura: string) {
    this.asignaturaService.deleteAsignatura(idasignatura)
      .subscribe(
        data => {
          console.log(data);
          this.reloadData();
        },
        error => console.log(error));
  }
}