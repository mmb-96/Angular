export class asignatura {
    idasignatura: string;
    nombre: string;
    creditos: number;
    cuatrimestre: number;
    costebasico: number;
    idprofesor: string;
    idtitulacion: string;
    curso: number;
}