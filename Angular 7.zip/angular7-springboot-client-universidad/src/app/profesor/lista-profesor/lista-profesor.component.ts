import { Component, OnInit } from '@angular/core';
import { Observable } from "rxjs";
import { ProfesorService } from "../../profesor.service";
import { profesor } from '../../profesor';

@Component({
  selector: 'app-lista-profesor',
  templateUrl: './lista-profesor.component.html',
  styleUrls: ['./lista-profesor.component.css']
})
export class ListaProfesorComponent implements OnInit {

  profesores: Observable<profesor[]>;

  constructor(private profesorService: ProfesorService) {}

  ngOnInit() {
    this.reloadData();
  }

  reloadData() {
    this.profesores = this.profesorService.getProfesorList();
  }

  deleteProfesor(dni: string) {
    this.profesorService.deleteProfesor(dni)
      .subscribe(
        data => {
          console.log(data);
          this.reloadData();
        },
        error => console.log(error));
  }

}