import { Component, OnInit } from '@angular/core';
import { ProfesorService } from "../../profesor.service";
import { profesor } from '../../profesor';

@Component({
  selector: 'app-crear-profesor',
  templateUrl: './crear-profesor.component.html',
  styleUrls: ['./crear-profesor.component.css']
})
export class CrearProfesorComponent implements OnInit {

  profesor: profesor = new profesor();
  submitted = false;

  constructor(private profesorServicio: ProfesorService) { }

  ngOnInit() {
  }

  newAlumno(): void {
    this.submitted = false;
    this.profesor = new profesor();
  }

  save() {
    this.profesorServicio.createProfesor(this.profesor)
      .subscribe(data => console.log(data), error => console.log(error));
    this.profesor = new profesor();
  }

  onSubmit() {
    this.submitted = true;
    this.save();
  }
}