export class titulacion {
    idtitulacion: string;
    nombre: string;
}