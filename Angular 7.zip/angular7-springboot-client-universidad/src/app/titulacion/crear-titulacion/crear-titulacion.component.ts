import { Component, OnInit } from '@angular/core';
import { TitulacionService } from '../../titulacion.service';
import { titulacion } from '../../titulacion';

@Component({
  selector: 'app-crear-titulacion',
  templateUrl: './crear-titulacion.component.html',
  styleUrls: ['./crear-titulacion.component.css']
})
export class CrearTitulacionComponent implements OnInit {

  titulacion: titulacion = new titulacion();
  submitted = false;

  constructor(private titulacionServicio: TitulacionService) { }

  ngOnInit() {
  }

  newTitulacion(): void {
    this.submitted = false;
    this.titulacion = new titulacion();
  }

  save() {
    this.titulacionServicio.createTitulacion(this.titulacion)
      .subscribe(data => console.log(data), error => console.log(error));
    this.titulacion = new titulacion();
  }

  onSubmit() {
    this.submitted = true;
    this.save();
  }

}