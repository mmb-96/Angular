import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DetallesTitulacionComponent } from './detalles-titulacion.component';

describe('DetallesTitulacionComponent', () => {
  let component: DetallesTitulacionComponent;
  let fixture: ComponentFixture<DetallesTitulacionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DetallesTitulacionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DetallesTitulacionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
