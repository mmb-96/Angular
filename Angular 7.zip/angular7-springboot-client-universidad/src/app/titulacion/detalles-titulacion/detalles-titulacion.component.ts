import { titulacion } from '../../titulacion';
import { Component, OnInit, Input } from '@angular/core';
import { TitulacionService } from '../../titulacion.service';
import { ListaTitulacionComponent } from '../lista-titulacion/lista-titulacion.component';

@Component({
  selector: 'app-detalles-titulacion',
  templateUrl: './detalles-titulacion.component.html',
  styleUrls: ['./detalles-titulacion.component.css']
})
export class DetallesTitulacionComponent implements OnInit {

  @Input() titulacion: titulacion;

  constructor(private titulacionService: TitulacionService, private listComponent: ListaTitulacionComponent) { }

  ngOnInit() {
  }

}