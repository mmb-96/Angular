import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ListaTitulacionComponent } from './lista-titulacion.component';

describe('ListaTitulacionComponent', () => {
  let component: ListaTitulacionComponent;
  let fixture: ComponentFixture<ListaTitulacionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ListaTitulacionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListaTitulacionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
