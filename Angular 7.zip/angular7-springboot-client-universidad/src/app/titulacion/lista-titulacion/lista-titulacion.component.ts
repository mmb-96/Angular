import { Component, OnInit } from '@angular/core';
import { Observable } from "rxjs";
import { TitulacionService } from "../../titulacion.service";
import { titulacion } from '../../titulacion';

@Component({
  selector: 'app-lista-titulacion',
  templateUrl: './lista-titulacion.component.html',
  styleUrls: ['./lista-titulacion.component.css']
})
export class ListaTitulacionComponent implements OnInit {
  titulacion: Observable<titulacion[]>;

  constructor(private titulacionService: TitulacionService) {}

  ngOnInit() {
    this.reloadData();
  }

  reloadData() {
    this.titulacion = this.titulacionService.getTitulacionList();
  }

  deleteTitulacion(idtitulacion: string) {
    this.titulacionService.deleteTitulacion(idtitulacion)
      .subscribe(
        data => {
          console.log(data);
          this.reloadData();
        },
        error => console.log(error));
  }
}