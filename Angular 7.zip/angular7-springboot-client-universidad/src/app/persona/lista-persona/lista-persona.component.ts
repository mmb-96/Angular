import { Component, OnInit } from '@angular/core';
import { Observable } from "rxjs";
import { PersonaService } from "../../persona.service";
import { persona } from '../../persona';

@Component({
  selector: 'app-lista-persona',
  templateUrl: './lista-persona.component.html',
  styleUrls: ['./lista-persona.component.css']
})
export class ListaPersonaComponent implements OnInit {
  personas: Observable<persona[]>;

  constructor(private personaService: PersonaService) {}

  ngOnInit() {
    this.reloadData();
  }

  reloadData() {
    this.personas = this.personaService.getPersonaList();
  }

  deletePersona(dni: string) {
    this.personaService.deletePersona(dni)
      .subscribe(
        data => {
          console.log(data);
          this.reloadData();
        },
        error => console.log(error));
  }
}