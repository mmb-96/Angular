import { Component, OnInit } from '@angular/core';
import { PersonaService } from "../../persona.service";
import { persona } from '../../persona';

@Component({
  selector: 'app-crear-persona',
  templateUrl: './crear-persona.component.html',
  styleUrls: ['./crear-persona.component.css']
})
export class CrearPersonaComponent implements OnInit {
  personas: persona = new persona();
  submitted = false;

  constructor(private personaServicio: PersonaService) { }

  ngOnInit() {
  }

  newPersona(): void {
    this.submitted = false;
    this.personas = new persona();
  }

  save() {
    this.personaServicio.createPersona(this.personas)
      .subscribe(data => console.log(data), error => console.log(error));
    this.personas = new persona();
  }

  onSubmit() {
    this.submitted = true;
    this.save();
  }

}