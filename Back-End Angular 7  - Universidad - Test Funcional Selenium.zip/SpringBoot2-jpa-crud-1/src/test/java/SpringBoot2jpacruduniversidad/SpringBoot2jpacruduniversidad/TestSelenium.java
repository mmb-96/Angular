package SpringBoot2jpacruduniversidad.SpringBoot2jpacruduniversidad;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

@FixMethodOrder(MethodSorters.JVM)
public class TestSelenium {
	
	private int port = 4200;
	private WebDriver driver;
	
	@Test
	public void testAnadirPersona() {
		driver = new ChromeDriver();
		driver.get("http://localhost:" + port);
		driver.findElement(By.linkText("Añadir Persona")).click();
		driver.findElement(By.id("dni")).sendKeys("30235421N");
		driver.findElement(By.id("nombre")).sendKeys("Manuel");
		driver.findElement(By.id("apellido")).sendKeys("Melero");
		driver.findElement(By.id("ciudad")).sendKeys("Sevilla");
		driver.findElement(By.id("direccioncalle")).sendKeys("Costa y Llobera");
		driver.findElement(By.id("direccionnum")).sendKeys("107");
		driver.findElement(By.id("telefono")).sendKeys("608707624");
		driver.findElement(By.id("varon")).sendKeys("1");
		driver.findElement(By.id("send")).click();
		
		assertThat(driver.findElement(By.id("secundario")).getText().contains("¡Tu envio ha sido satisfactorio!"));
	}
	
	
	@Test
	public void testDeletePersona() {
		driver = new ChromeDriver();
		driver.get("http://localhost:" + port);
		driver.findElement(By.linkText("Personas")).click();
		driver.findElement(By.id("delete30235421N")).click();
		
		assertThat(!driver.findElement(By.id("delete30235421N")).getText().contains("delete30235421N"));
	}

}
