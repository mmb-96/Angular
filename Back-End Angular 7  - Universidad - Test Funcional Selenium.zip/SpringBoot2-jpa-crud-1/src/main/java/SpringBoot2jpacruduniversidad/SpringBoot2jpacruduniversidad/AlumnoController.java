package SpringBoot2jpacruduniversidad.SpringBoot2jpacruduniversidad;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javassist.tools.web.BadHttpRequest;

@RestController
@RequestMapping(path = "/alumno")
public class AlumnoController {
	
	@Autowired
	private AlumnoRepo alumnorepo;
	
	@GetMapping
    public Iterable<Alumno> findAll() {
        return alumnorepo.findAll();
    }

    @GetMapping(path = "/{dni}")
    public Optional<Alumno> find(@PathVariable("dni") String dni) {
        return alumnorepo.findById(dni);
    }

    @PostMapping(consumes = "application/json")
    public Alumno create(@RequestBody Alumno alumno) {
        return alumnorepo.save(alumno);
    }

    @DeleteMapping(path = "/{dni}")
    public void delete(@PathVariable("dni") String dni) {
    	alumnorepo.deleteById(dni);
    }

    @PutMapping(path = "/{dni}")
    public Alumno update(@PathVariable("dni") String dni, @RequestBody Alumno alumno) throws BadHttpRequest {
        if (alumnorepo.existsById(dni)) {
        	alumno.setDni(dni);
            return alumnorepo.save(alumno);
        } else {
            throw new BadHttpRequest();
        }
    }

}
