package SpringBoot2jpacruduniversidad.SpringBoot2jpacruduniversidad;

import org.springframework.data.jpa.repository.JpaRepository;

import org.springframework.data.rest.core.annotation.RestResource;

@RestResource(exported = false)
public interface ProfesorRepo extends JpaRepository<Profesor, String>{
	
}