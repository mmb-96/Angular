package SpringBoot2jpacruduniversidad.SpringBoot2jpacruduniversidad;
import java.io.Serializable;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="Profesor")
public class Profesor extends Persona implements Serializable {
	
	@Column(name="Idprofesor")
	private String idprofesor;

	
	public Profesor() {
		
	}

	public Profesor(String idprofesor, String dni) {
		super.setDni(dni);
		this.idprofesor = idprofesor;
	}

	public String getIdprofesor() {
		return idprofesor;
	}

	public void setIdprofesor(String idprofesor) {
		this.idprofesor = idprofesor;
	}

	public String toString() {
		return super.toString() + "Profesor [idprofesor=" + idprofesor + "]\n";
	}
}